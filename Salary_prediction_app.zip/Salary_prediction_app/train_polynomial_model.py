import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
import pickle

# Exemple de données
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9]).reshape(-1, 1)
y = np.array([30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000])

poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)

model_poly = LinearRegression()
model_poly.fit(X_poly, y)

# Sauvegarde
with open("model_Polynomial_Salary.pkl", "wb") as f:
    pickle.dump(model_poly, f)

print("✅ model_Polynomial_Salary.pkl créé avec succès")

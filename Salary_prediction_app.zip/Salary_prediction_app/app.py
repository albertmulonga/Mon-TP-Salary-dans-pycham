# ================== IMPORTS ==================
from flask import Flask, render_template, request, redirect, url_for, session, flash
import pandas as pd
import numpy as np
import os
import pickle
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.tree import DecisionTreeClassifier

# ================== APP CONFIG ==================
app = Flask(__name__)
app.secret_key = "secret_feta_ml"

# ================== AUTH CONFIG ==================
EMAIL_AUTORISE = "feta@gmail.com"
PASSWORD_AUTORISE = "1234"

# ================== BASE DIR ==================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ================== LOAD DATA ==================
df_salary = pd.read_csv(os.path.join(BASE_DIR, "salary_data.csv"))

# ================== LINEAR MODEL ==================
linear_model = LinearRegression()
X_linear = df_salary[['YearsExperience']]
y_linear = df_salary['Salary']
linear_model.fit(X_linear, y_linear)

# ================== POLYNOMIAL GLOBAL VARS ==================
dataset_poly = None
X_train = X_test = y_train = y_test = None
poly_model = None
poly_features = None
historique_poly = []

# ================== LOAD ML MODELS ==================
# Assure-toi que les fichiers .pkl sont dans la racine du projet
with open(os.path.join(BASE_DIR, "model_Diabete_prediction.pkl"), "rb") as f:
    diabete_model = pickle.load(f)

with open(os.path.join(BASE_DIR, "model_Student_performance.pkl"), "rb") as f:
    student_model = pickle.load(f)

# ================== ROUTES ==================

@app.route("/")
def splash():
    return render_template("splash.html")

# ---------- LOGIN ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["email"] == EMAIL_AUTORISE and request.form["password"] == PASSWORD_AUTORISE:
            session["user"] = EMAIL_AUTORISE
            return redirect(url_for("home"))
        flash("Email ou mot de passe incorrect", "danger")
    return render_template("login.html")

# ---------- HOME ----------
@app.route("/home")
def home():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template(
        "home.html",
        n_exemples=len(df_salary),
        graph_url=""  # tu peux générer un graph ici si besoin
    )

# ---------- SALARY LINEAR ----------
@app.route("/salary", methods=["GET", "POST"])
def salary():
    if "user" not in session:
        return redirect(url_for("login"))

    prediction_text = None
    if request.method == "POST":
        exp = float(request.form["Annees_Exp"])
        pred = linear_model.predict([[exp]])[0]
        prediction_text = f"{pred:,.2f} USD"

    return render_template(
        "salary.html",
        prediction_text=prediction_text,
        n_exemples=len(df_salary)
    )

# ---------- POLYNOMIAL ----------
@app.route("/polynomial", methods=["GET", "POST"])
def polynomial():
    if "user" not in session:
        return redirect(url_for("login"))

    prediction_text = None
    if request.method == "POST":
        exp = float(request.form["Annees_Exp"])
        if poly_model and poly_features:
            pred = poly_model.predict(poly_features.transform([[exp]]))[0]
            prediction_text = f"{pred:,.2f} USD"
            historique_poly.append({"experience": exp, "prediction": prediction_text})
        else:
            flash("Veuillez exécuter les étapes d'abord", "warning")

    taches = [
        "Collecte des données",
        "Analyse des données",
        "Transformation polynomiale",
        "Division en train/test",
        "Entraînement du modèle",
        "Prédiction et évaluation"
    ]

    return render_template(
        "polynomial.html",
        prediction_text=prediction_text,
        historique=historique_poly,
        taches=taches
    )

@app.route("/polynomial/tache/<nom_tache>")
def tache_polynomial(nom_tache):
    global dataset_poly, X_train, X_test, y_train, y_test, poly_model, poly_features

    if "user" not in session:
        return redirect(url_for("login"))

    nom_tache = nom_tache.replace("_", " ")

    try:
        if nom_tache == "Collecte des données":
            X = df_salary[['YearsExperience']].values
            y = df_salary['Salary'].values
            dataset_poly = (X, y)
            flash("✅ Données collectées", "success")

        elif nom_tache == "Analyse des données":
            _, y = dataset_poly
            flash(f"Moyenne={np.mean(y):.2f}", "info")

        elif nom_tache == "Transformation polynomiale":
            poly_features = PolynomialFeatures(degree=2)
            X_poly = poly_features.fit_transform(dataset_poly[0])
            dataset_poly = (X_poly, dataset_poly[1])
            flash("Transformation polynomiale OK", "success")

        elif nom_tache == "Division en train/test":
            X_train, X_test, y_train, y_test = train_test_split(
                dataset_poly[0], dataset_poly[1], test_size=0.2, random_state=42
            )
            poly_model = LinearRegression()
            poly_model.fit(X_train, y_train)
            flash("Train/Test + entraînement OK", "success")

        elif nom_tache == "Prédiction et évaluation":
            y_pred = poly_model.predict(X_test)
            rmse = np.sqrt(mean_squared_error(y_test, y_pred))
            r2 = r2_score(y_test, y_pred)
            flash(f"RMSE={rmse:.2f} | R²={r2:.2f}", "info")

    except Exception as e:
        flash(str(e), "danger")

    return redirect(url_for("polynomial"))

# ---------- DIABETE ----------
@app.route("/diabete", methods=["GET", "POST"])
def diabete():
    if "user" not in session:
        return redirect(url_for("login"))

    prediction = None
    if request.method == "POST":
        try:
            # Conversion des inputs
            pregnancies = int(request.form["pregnancies"])
            glucose = float(request.form["glucose"])
            bloodpressure = float(request.form["bloodpressure"])
            skinthickness = float(request.form["skinthickness"])
            insulin = float(request.form["insulin"])
            bmi = float(request.form["bmi"])
            dpf = float(request.form["dpf"])
            age = int(request.form["age"])

            # Prédiction
            res = diabete_model.predict([[pregnancies, glucose, bloodpressure, skinthickness, insulin, bmi, dpf, age]])
            prediction = "💉 Diabète : " + ("Oui" if int(res[0]) == 1 else "Non")

        except Exception as e:
            flash(f"Erreur : {str(e)}", "danger")

    return render_template("diabete.html", prediction=prediction)

# ---------- STUDENT PERFORMANCE ----------
@app.route("/student", methods=["GET", "POST"])
def student():
    if "user" not in session:
        return redirect(url_for("login"))

    prediction = None
    if request.method == "POST":
        try:
            # Récupération des inputs
            heures = float(request.form["study_hours"])
            absences = int(request.form["absences"])
            assignments = int(request.form["assignments_completed"])
            previous_score = float(request.form["previous_score"])

            # Prédiction
            res = student_model.predict([[heures, absences, assignments, previous_score]])
            score = float(res[0])  # Conversion pour éviter TypeError
            prediction = f"🎓 Score estimé : {score:.2f}"

        except Exception as e:
            flash(f"Erreur : {str(e)}", "danger")

    taches = [
        "Chargement du modèle étudiant",
        "Entrée des données académiques",
        "Prédiction de la performance",
        "Analyse du score"
    ]

    return render_template(
        "student.html",
        prediction=prediction,
        taches=taches
    )

# ---------- LOGOUT ----------
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ================== RUN ==================
if __name__ == "__main__":
    app.run(debug=True)
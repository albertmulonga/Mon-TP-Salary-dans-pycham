* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

/* SPLASH SCREEN */
#splash {
    position: fixed;
    width: 100%;
    height: 100%;
    background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)),
                url("splash.jpg") center/cover no-repeat;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    animation: fadeOut 1s ease forwards;
    animation-delay: 2s;
}

.splash-content {
    text-align: center;
    color: white;
    animation: zoomIn 1.5s ease;
}

.splash-content h1 {
    font-size: 3em;
}

.splash-content p {
    font-size: 1.2em;
    margin-top: 10px;
}

/* MAIN PAGE */
body {
    background: linear-gradient(135deg, #1d2671, #c33764);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    background: white;
    padding: 40px;
    width: 420px;
    border-radius: 15px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    animation: slideUp 1.5s ease;
}

.container h1 {
    color: #1d2671;
}

.subtitle {
    color: #555;
    margin-bottom: 25px;
}

label {
    display: block;
    text-align: left;
    margin-bottom: 8px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
}

button {
    width: 100%;
    padding: 12px;
    background: #1d2671;
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #c33764;
}

.result {
    margin-top: 20px;
    padding: 15px;
    background: #e6f7ff;
    border-left: 5px solid #1d2671;
    font-weight: bold;
    color: #333;
}

/* ANIMATIONS */
@keyframes zoomIn {
    from { transform: scale(0.5); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}

@keyframes slideUp {
    from { transform: translateY(50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

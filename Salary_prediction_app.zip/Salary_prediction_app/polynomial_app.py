import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

st.set_page_config(page_title="TP Régression Polynomiale", layout="wide")

st.title("📊 TP : Régression Polynomiale")
st.markdown("---")

menu = st.sidebar.radio(
    "📌 Étapes du TP",
    [
        "1️⃣ Collecte des données",
        "2️⃣ Analyse des données",
        "3️⃣ Transformation polynomiale",
        "4️⃣ Division Train/Test",
        "5️⃣ Entraînement du modèle",
        "6️⃣ Prédiction & Évaluation"
    ]
)

# ===============================
# VARIABLES GLOBALES (SESSION)
# ===============================
if "df" not in st.session_state:
    st.session_state.df = None
if "X_train" not in st.session_state:
    st.session_state.X_train = None
if "X_test" not in st.session_state:
    st.session_state.X_test = None
if "y_train" not in st.session_state:
    st.session_state.y_train = None
if "y_test" not in st.session_state:
    st.session_state.y_test = None
if "model" not in st.session_state:
    st.session_state.model = None
if "poly" not in st.session_state:
    st.session_state.poly = None

# ===============================
# 1. COLLECTE
# ===============================
if menu == "1️⃣ Collecte des données":
    st.subheader("📥 Chargement des données")

    file = st.file_uploader("Importer le fichier CSV", type=["csv"])

    if file:
        st.session_state.df = pd.read_csv(file)
        st.success("✅ Données chargées avec succès")
        st.dataframe(st.session_state.df)

# ===============================
# 2. ANALYSE
# ===============================
elif menu == "2️⃣ Analyse des données":
    if st.session_state.df is None:
        st.warning("⚠️ Collectez d'abord les données.")
    else:
        st.subheader("📊 Analyse des données")
        st.write(st.session_state.df.describe())

# ===============================
# 3. TRANSFORMATION
# ===============================
elif menu == "3️⃣ Transformation polynomiale":
    if st.session_state.df is None:
        st.warning("⚠️ Collectez d'abord les données.")
    else:
        degree = st.slider("Degré polynomial", 2, 5, 2)

        X = st.session_state.df.iloc[:, 0:1].values
        y = st.session_state.df.iloc[:, 1].values

        poly = PolynomialFeatures(degree=degree)
        X_poly = poly.fit_transform(X)

        st.session_state.poly = poly
        st.success("✅ Transformation polynomiale appliquée")

        st.write("Extrait des données transformées :")
        st.write(X_poly[:5])

# ===============================
# 4. DIVISION
# ===============================
elif menu == "4️⃣ Division Train/Test":
    if st.session_state.df is None or st.session_state.poly is None:
        st.warning("⚠️ Faites d'abord la transformation polynomiale.")
    else:
        X = st.session_state.df.iloc[:, 0:1].values
        y = st.session_state.df.iloc[:, 1].values

        X_poly = st.session_state.poly.transform(X)

        X_train, X_test, y_train, y_test = train_test_split(
            X_poly, y, test_size=0.2, random_state=42
        )

        st.session_state.X_train = X_train
        st.session_state.X_test = X_test
        st.session_state.y_train = y_train
        st.session_state.y_test = y_test

        st.success("✅ Données divisées (Train/Test)")

# ===============================
# 5. ENTRAINEMENT
# ===============================
elif menu == "5️⃣ Entraînement du modèle":
    if st.session_state.X_train is None:
        st.warning("⚠️ Divisez d'abord les données.")
    else:
        model = LinearRegression()
        model.fit(st.session_state.X_train, st.session_state.y_train)

        st.session_state.model = model
        st.success("🎯 Modèle entraîné avec succès")

# ===============================
# 6. PREDICTION
# ===============================
elif menu == "6️⃣ Prédiction & Évaluation":
    if st.session_state.model is None:
        st.warning("⚠️ Entraînez d'abord le modèle.")
    else:
        y_pred = st.session_state.model.predict(st.session_state.X_test)

        mse = mean_squared_error(st.session_state.y_test, y_pred)
        r2 = r2_score(st.session_state.y_test, y_pred)

        st.success("📈 Résultats de l'évaluation")
        st.write(f"**MSE :** {mse:.2f}")
        st.write(f"**R² Score :** {r2:.2f}")
